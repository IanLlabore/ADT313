import React, { useState, useEffect, useRef, useCallback, useReducer, useContext } from 'react';
import './App.css';


const ProfileContext = React.createContext();

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const profileInfo = {
    name: 'Ian Llabore',
    birthday: 'Dec 1, 2003',
    section: 'BSIT3A'
  };

  return (
    <ProfileContext.Provider value={profileInfo}>
      <div className="App dark-theme">
        <h1>Dr. Yanga's Colleges Inc.</h1>
        {isLoggedIn ? (
          <Dashboard setIsLoggedIn={setIsLoggedIn} />
        ) : (
          <LoginForm setIsLoggedIn={setIsLoggedIn} setIsLoading={setIsLoading} />
        )}
        {isLoading && <p>Loading...</p>}
        <Calculator />
      </div>
    </ProfileContext.Provider>
  );
}

function LoginForm({ setIsLoggedIn, setIsLoading }) {
  const [user, setUser] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  
  const usernameRef = useRef();
  const passwordRef = useRef();

  const togglePasswordVisibility = useCallback(() => {
    setShowPassword(prev => !prev);
  }, []);

  const validateForm = useCallback(() => {
    if (!user.username || !user.password) {
      setError('Username and password are required');
      return false;
    }
    setError('');
    return true;
  }, [user]);

  const handleLogin = useCallback((e) => {
    e.preventDefault();
    if (validateForm()) {
      setIsLoading(true);
      
      setTimeout(() => {
        if (user.username === 'user' && user.password === 'Password123@') {
          alert('Login successful!');
          setIsLoggedIn(true);
        } else {
          alert('Invalid username or password');
          setError('Invalid username or password');
        }
        setIsLoading(false);
      }, 2000);
    }
  }, [user, validateForm, setIsLoggedIn, setIsLoading]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (user.username || user.password) {
        validateForm();
      }
    }, 2000);
    return () => clearTimeout(timer);
  }, [user, validateForm]);

  return (
    <form onSubmit={handleLogin}>
      <input
        type="text"
        ref={usernameRef}
        value={user.username}
        onChange={(e) => setUser({ ...user, username: e.target.value })}
        placeholder="Username"
      />
      <input
        type={showPassword ? "text" : "password"}
        ref={passwordRef}
        value={user.password}
        onChange={(e) => setUser({ ...user, password: e.target.value })}
        placeholder="Password"
      />
      <button type="button" onClick={togglePasswordVisibility}>
        {showPassword ? 'Hide' : 'Show'} Password
      </button>
      <button type="submit">Login</button>
      {error && <p>{error}</p>}
    </form>
  );
}

function Dashboard({ setIsLoggedIn }) {
  const profileInfo = useContext(ProfileContext);
  const [showLogoutPrompt, setShowLogoutPrompt] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleLogout = useCallback(() => {
    setShowLogoutPrompt(true);
  }, []);

  const confirmLogout = useCallback(() => {
    setIsLoggedIn(false);
    setShowLogoutPrompt(false);
    alert('You have been logged out.');
  }, [setIsLoggedIn]);

  return (
    <div>
      <h2>Welcome, {profileInfo.name}!</h2>
      <p>Birthday: {profileInfo.birthday}</p>
      <p>Section: {profileInfo.section}</p>
      <button onClick={handleLogout}>Logout</button>
      {showLogoutPrompt && (
        <div>
          <p>Are you sure you want to logout?</p>
          <button onClick={confirmLogout}>Yes</button>
          <button onClick={() => setShowLogoutPrompt(false)}>No</button>
        </div>
      )}
    </div>
  );
}

function calculatorReducer(state, action) {
  switch (action.type) {
    case 'SET_NUMBER':
      return { ...state, [action.payload.name]: action.payload.value };
    case 'SET_OPERATION':
      return { ...state, operation: action.payload };
    case 'CALCULATE':
      const { firstNumber, secondNumber, operation } = state;
      let result;
      switch (operation) {
        case 'add':
          result = parseFloat(firstNumber) + parseFloat(secondNumber);
          break;
        case 'subtract':
          result = parseFloat(firstNumber) - parseFloat(secondNumber);
          break;
        case 'multiply':
          result = parseFloat(firstNumber) * parseFloat(secondNumber);
          break;
        case 'divide':
          result = parseFloat(secondNumber) !== 0 
            ? parseFloat(firstNumber) / parseFloat(secondNumber)
            : 'Error: Division by zero';
          break;
        default:
          result = 'Error: Invalid operation';
      }
      return { ...state, result };
    default:
      return state;
  }
}

function Calculator() {
  const [state, dispatch] = useReducer(calculatorReducer, {
    firstNumber: '',
    secondNumber: '',
    operation: '',
    result: null
  });

  const handleNumberChange = (e) => {
    dispatch({ 
      type: 'SET_NUMBER', 
      payload: { name: e.target.name, value: e.target.value } 
    });
  };

  const handleOperation = (op) => {
    dispatch({ type: 'SET_OPERATION', payload: op });
  };

  const calculate = () => {
    dispatch({ type: 'CALCULATE' });
  };

  const getOperationSymbol = (operation) => {
    switch (operation) {
      case 'add': return '+';
      case 'subtract': return '-';
      case 'multiply': return '×';
      case 'divide': return '÷';
      default: return '?';
    }
  };

  return (
    <div>
      <input
        type="number"
        name="firstNumber"
        value={state.firstNumber}
        onChange={handleNumberChange}
      />
      <span>{getOperationSymbol(state.operation)}</span>
      <input
        type="number"
        name="secondNumber"
        value={state.secondNumber}
        onChange={handleNumberChange}
      />
      <div>
        <button onClick={() => handleOperation('add')}>Add</button>
        <button onClick={() => handleOperation('subtract')}>Subtract</button>
        <button onClick={() => handleOperation('multiply')}>Multiply</button>
        <button onClick={() => handleOperation('divide')}>Divide</button>
      </div>
      <button onClick={calculate}>Calculate</button>
      <p>Result: {state.result}</p>
    </div>
  );
}

export default App;
