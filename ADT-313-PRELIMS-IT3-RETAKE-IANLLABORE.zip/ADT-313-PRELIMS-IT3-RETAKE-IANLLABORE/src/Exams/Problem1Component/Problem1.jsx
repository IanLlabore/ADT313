function Problem1() {
    const {setCurrentUser} = useContext(CurrentUserContext);
    const [studentName, setStudentName] = useState('');
    const [Course, setCourse] = useState('');
    const [Section, setSection] = useState('');
    const canLogin = firstName.trim() !== '' && lastName.trim() !== '';
    return (
        <>
        <label>
            Student name{': '}
            <input
            required
            value={studentName}
            onChange={e => setStudentName(e.target.value)}
            />
        </label>
        <label>
            Course{': '}
            <input
            required
            value={Course}
            onChange={e => setCourse(e.target.value)}
            />
        </label>
        <label>
            Section{': '}
            <input
            required
            value={Section}
            onChange={e => setSection(e.target.value)}
            />
        </label>
        <Button
            disabled={!canLogin}
            onClick={() => {
            setCurrentUser({
                name: studentName + ' ' + Section
            });
            }}
        >
            Add
        </Button>
        {!canLogin && <i>Add Students</i>}
        </>
    );

}
function Button({ children, disabled, onClick }) {
    const theme = useContext(ThemeContext);
    const className = 'button-' + theme;
    return (
      <button
        className={className}
        disabled={disabled}
        onClick={onClick}
      >
        {children}
      </button>
    );
}